import React from 'react'

const Textmasseg = () => {
  return (
    <span>Textmasseg</span>
  )
}

export default Textmasseg